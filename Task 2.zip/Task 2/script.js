const todoForm = document.getElementById('todo-form');
const todoInput = document.getElementById('todo-input');
const todoList = document.getElementById('todo-list');

// Add task
todoForm.addEventListener('submit', function(event) {
    event.preventDefault();
    const taskText = todoInput.value.trim();

    if (taskText !== '') {
        addTask(taskText);
        todoInput.value = '';
    }
});

// Function to add task to the list
function addTask(taskText) {
    const li = document.createElement('li');
    li.innerText = taskText;

    const deleteButton = document.createElement('button');
    deleteButton.innerText = 'Delete';
    deleteButton.className = 'delete-btn';
    deleteButton.addEventListener('click', function() {
        li.remove();
    });

    const completeButton = document.createElement('button');
    completeButton.innerText = 'Complete';
    completeButton.className = 'complete-btn';
    completeButton.addEventListener('click', function() {
        li.classList.toggle('completed');
    });

    li.appendChild(deleteButton);
    li.appendChild(completeButton);
    todoList.appendChild(li);
}
